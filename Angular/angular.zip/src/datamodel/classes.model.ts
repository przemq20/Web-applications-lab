
export interface Class {
    name: string;
    sciezka: string;
    icon: string;
    ECTS: number;
    semester: number;
    form: string;
    maxstudents: number;
    mark: number;
}
