import { Injectable } from '@angular/core';

@Injectable()
export class DataStorage {
    public data: any;
    public constructor() { }
}
