export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyCvv2mS91kuEwNFNOp8bh88r7DkQw34qQs',
    authDomain: 'classes-db0a3.firebaseapp.com',
    databaseURL: 'https://classes-db0a3.firebaseio.com',
    projectId: 'classes-db0a3',
    storageBucket: 'classes-db0a3.appspot.com',
    messagingSenderId: '1018446899990',
    appId: '1:1018446899990:web:9ddfc02d53a49066dffe37',
    measurementId: 'G-QSQJ46ZSMY',
  }
};
